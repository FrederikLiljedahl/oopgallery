let spiller_1 = {
    fornavn: 'jens',
    efternavn: 'Hansen',
    status: 'false',
    point: 0,
    skiftStatus: function () {
        this.status = !this.status;
    },
    givPoint: function (antal) {
        this.point += antal;
    },
    profil: function () {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`
    }

}
console.log(spiller_1.profil())