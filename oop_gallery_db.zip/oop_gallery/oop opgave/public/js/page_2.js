document.addEventListener("DOMContentLoaded", function (event) {

    fetch('http://localhost:1337/billeder')
        .then((response) => {
            // grib svarets indhold (body) og send det som et json objekt til næste .then()
            return response.json();
        }).then((data) => {
            getdata(data)
        })

    function getdata(data) {


        let allimages = []
        data.forEach((billede) => {
            let billede_object = new Billede(billede.filnavn, billede.titel, billede.navn, billede.kategori_navn, billede.dato)
            console.log(billede_object)
            allimages.push(
                billede_object
            )

        })

        OOPGallery1 = new OOPGallery('#gallery01', allimages);

    }






    // version 2:  her har vi bestemt hvor mange oplysniner(id,filnavn,fotograf) fra databasen der skal indsættes i galleriet
    // function getdata(data) {
    //     console.log(data)

    //     let allimages = []
    //     data.forEach((data_object) => {

    //         allimages.push({
    //             id: data_object.id,
    //             filnavn: data_object.filnavn
    //         })

    //     })

    //     OOPGallery1 = new OOPGallery('#gallery01', allimages);
    //     console.log(OOPGallery1)
    // }



    // version 1: her har vi ikke bestemt hvor mange oplysniner(id,filnavn,fotograf) fra databasen der skal indsættes i galleriet
    // function getdata(data) {
    //     console.log(data)
    //     OOPGallery1 = new OOPGallery('#gallery01', data);
    // }
});

