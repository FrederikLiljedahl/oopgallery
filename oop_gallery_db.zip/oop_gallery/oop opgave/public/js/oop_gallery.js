
class OOPGallery {
	constructor(gallery_selector, images_array) {
		this.index = 0;
		this.gallery_element = document.querySelector(gallery_selector);
		this.image_element = this.gallery_element.querySelector('.oopgallery-image');
		this.image_data = images_array;
		let gallery_object = this;

		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-next').addEventListener('click', function (event) {
			gallery_object.gotoImageNext()

		});
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-previous').addEventListener('click', function (event) {
			gallery_object.gotoImagePrevious()
		});

		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-first').addEventListener('click', function (event) {
			gallery_object.gotoImageFirst()
		});
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-last').addEventListener('click', function (event) {
			gallery_object.gotoImageLast()
		});

		this.updateImage();
	}
	updateImage() {
		this.image_element.src = this.image_data[this.index].filnavn;
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-image-number').innerHTML = `${this.index + 1} / ${this.image_data.length}`
		this.gallery_element.querySelector('.titel h3').innerHTML = this.image_data[this.index].titel;
		this.gallery_element.querySelector('.fotograf p').innerHTML = this.image_data[this.index].fotograf;
		this.gallery_element.querySelector('.kategori p').innerHTML = this.image_data[this.index].kategori;
		this.gallery_element.querySelector('.dato p').innerHTML = this.image_data[this.index].dato;
	}

	gotoImageNext() {
		this.index++;
		if (this.index >= this.image_data.length) {
			this.index = 0
		}
		this.updateImage()

	}
	gotoImagePrevious() {
		this.index--;
		if (this.index === -1) {
			this.index = this.image_data.length - 1;
		}
		this.updateImage()
	}

	gotoImageFirst() {
		this.index = 0
		this.updateImage()
	}

	gotoImageLast() {
		this.index = this.image_data.length - 1;
		this.updateImage()
	}
}
class Billede {
	constructor(filnavn, titel, fotograf, kategori, dato) {
		this.filnavn = filnavn
		this.titel = titel
		this.fotograf = fotograf
		this.kategori = kategori
		this.dato = dato
	}
}
