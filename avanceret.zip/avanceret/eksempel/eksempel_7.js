
class spiller {
    constructor(fornavn, efternavn) {
        this.fornavn = fornavn;
        this.efternavn = efternavn;
        this.status = false;
        this.point = 0;

    }
    skiftStatus() {
        this.status = !this.status;
    }
    givPoint(antal) {
        this.point += antal;
    }
    profil() {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`;
    }

    static hentspillerliste() {
        let liste = [];
        liste.push(new spiller("peter", "hansen"));
        liste.push(new spiller("peter", "jensen"));
        return liste;
    }

    static findspiller(liste = [], search = "") {
        liste.forEach(function (spiller) {
            if (spiller.fornavn.toLowerCase()
                .indexOf(search.toLowerCase()) > -1) {
                console.log(spiller.profil());
            }
        });

    }
}
let spillerliste = spiller.hentspillerliste();

spiller.findspiller(spillerliste, 'e')
