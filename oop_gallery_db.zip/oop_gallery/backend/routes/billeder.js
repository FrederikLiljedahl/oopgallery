const db = require('../config/sql').connect();

module.exports = function (app) {

    // Route hent alle produkter
    app.get('/billeder', function (req, res) {
        var sql = `SELECT 
        billede.id,
        billede.titel,
        billede.filnavn,
        billede.dato,
        kategori.kategori_navn,
        fotograf.navn
        FROM billede 
        INNER JOIN kategori
        ON billede.kategori_id = kategori.id
        INNER JOIN fotograf
        ON billede.fotograf_id = fotograf.id`;
        db.query(sql, function (err, data) {
            if (err) {
                console.log(err)
            }
            res.send(data);
        })
    })

}