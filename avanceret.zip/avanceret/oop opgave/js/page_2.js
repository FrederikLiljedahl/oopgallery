
let images = [
    "images/image_01.jpg",
    "images/image_02.jpg",
    "images/image_04.jpg",
    "images/image_05.jpg"
]
OOPGallery1 = new OOPGallery('#gallery01', images);

images = [
    "images/image_04.jpg",
    "images/image_07.jpg",
    "images/image_03.jpg",
    "images/image_06.jpg"
]
OOPGallery2 = new OOPGallery('#gallery02', images);




