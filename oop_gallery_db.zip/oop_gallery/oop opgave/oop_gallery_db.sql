-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Vært: 127.0.0.1
-- Genereringstid: 20. 03 2018 kl. 14:27:29
-- Serverversion: 5.6.24
-- PHP-version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `oop_gallery_db`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `billede`
--

CREATE TABLE IF NOT EXISTS `billede` (
  `id` int(11) NOT NULL,
  `titel` varchar(30) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `filnavn` varchar(30) NOT NULL,
  `dato` date NOT NULL,
  `fotograf_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `billede`
--

INSERT INTO `billede` (`id`, `titel`, `kategori_id`, `filnavn`, `dato`, `fotograf_id`) VALUES
(3, 'peters billede', 1, 'images/image_01.jpg', '2018-03-06', 11),
(4, 'franks billede', 1, 'images/image_02.jpg', '2018-03-22', 12),
(5, 'landet', 1, 'images/image_03.jpg', '2018-03-29', 11);

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `fotograf`
--

CREATE TABLE IF NOT EXISTS `fotograf` (
  `id` int(11) NOT NULL,
  `navn` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `fotograf`
--

INSERT INTO `fotograf` (`id`, `navn`) VALUES
(11, 'peter'),
(12, 'frank');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id` int(11) NOT NULL,
  `kategori_navn` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `kategori`
--

INSERT INTO `kategori` (`id`, `kategori_navn`) VALUES
(1, 'sport');

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `billede`
--
ALTER TABLE `billede`
  ADD PRIMARY KEY (`id`), ADD KEY `kategori_id` (`kategori_id`), ADD KEY `fotograf_id` (`fotograf_id`), ADD KEY `fotograf_id_2` (`fotograf_id`), ADD KEY `fotograf_id_3` (`fotograf_id`), ADD KEY `fotograf_id_4` (`fotograf_id`);

--
-- Indeks for tabel `fotograf`
--
ALTER TABLE `fotograf`
  ADD PRIMARY KEY (`id`);

--
-- Indeks for tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `billede`
--
ALTER TABLE `billede`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Tilføj AUTO_INCREMENT i tabel `fotograf`
--
ALTER TABLE `fotograf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- Tilføj AUTO_INCREMENT i tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Begrænsninger for dumpede tabeller
--

--
-- Begrænsninger for tabel `billede`
--
ALTER TABLE `billede`
ADD CONSTRAINT `billede_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `kategori` (`id`),
ADD CONSTRAINT `billede_ibfk_2` FOREIGN KEY (`fotograf_id`) REFERENCES `fotograf` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
