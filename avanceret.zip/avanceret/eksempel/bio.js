
class biograf {
    constructor(tittle, tidspunkt, personer, stjerner) {
        this.tittle = tittle;
        this.tidspunkt = tidspunkt;
        this.status = false;
        this.pris = 90 * personer;
        this.bedømmelse = stjerner;
    }

    skiftStatus() {
        this.status = !this.status;
    }
    prisen() {
        this.pris;
    }

    givbedømmelse() {
        this.bedømmelse;
    }
    automat() {
        return `${this.tittle} kører kl.${this.tidspunkt} med en bedømmelse på ${this.bedømmelse} ud af 5. Den koster kun ${this.pris} for jer. Den er ${this.status ? "Startet" : "ikke startet endnu"}`;
    }
}
let personer = 10;
let stjerner = 5;
let time = new Date();

let filmliste = [];
filmliste.push(new biograf("black Panther", time.getHours(), personer, stjerner));

filmliste.forEach(function (biograf) {

    console.log(biograf.automat())
})