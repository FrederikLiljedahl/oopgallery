const restify = require('restify');
const corsmiddleware = require('restify-cors-middleware');
const server = restify.createServer({
    'name': 'oop_gallery',
    'version': '1.0.0'
});

server.use(restify.plugins.acceptParser(server.acceptable));
server.use(restify.plugins.bodyParser());
server.use(restify.plugins.jsonp());
const cors = corsmiddleware({
    origins: ['*']
    // 'allowHeaders': ['Authorization', 'userID']
});

server.pre(cors.preflight);
server.use(cors.actual);

require('./routes/index')(server);


server.listen(1337);
console.log('så køre bussen')


