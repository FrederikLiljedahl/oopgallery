module.exports = (app) => {
    require('./billeder')(app);

};