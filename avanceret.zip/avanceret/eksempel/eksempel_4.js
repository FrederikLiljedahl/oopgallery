
class spiller {
    constructor(fornavn, efternavn) {
        this.fornavn = fornavn;
        this.efternavn = efternavn;
        this.status = false;
        this.point = 0;

    }
    skiftStatus() {
        this.status = !this.status;
    }
    givPoint(antal) {
        this.point += antal;
    }
    profil() {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`;
    }

}
let spiller_1 = new spiller('palle', 'Olsen');
let spiller_2 = new spiller('Tina', 'jensen');

spiller_1.skiftStatus();
spiller_1.givPoint(5);

spiller_2.givPoint(-10);

console.log(`1. ${spiller_1.profil()}\n2. ${spiller_2.profil()}`);