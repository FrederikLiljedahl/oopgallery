
class spiller {
    constructor(fornavn, efternavn) {
        this.fornavn = fornavn;
        this.efternavn = efternavn;
        this.status = false;
        this.point = 0;

    }
    skiftStatus() {
        this.status = !this.status;
    }
    givPoint(antal) {
        this.point += antal;
    }
    profil() {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`;
    }

    static hentspillerliste() {
        let liste = [];
        liste.push(new spiller("peter", "hansen"));
        liste.push(new spiller("peter", "jensen"));
        return liste;
    }

}

let spillerliste = spiller.hentspillerliste();

console.log(spillerliste)