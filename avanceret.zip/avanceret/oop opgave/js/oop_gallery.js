
// Denne fil må kun indeholde definitionen på gallery objektet.
// Altså må der ikke stå "new OOPGallery()" nogen steder i denne fil.

// Hvis en hjemmeside f.eks. har 3 gallerier på samme underside,
// så må de 3 gallerier IKKE nævnes specifikt her!

// Spørg, hvis du er i tvivl omkring reglerne.




class OOPGallery {
	constructor(gallery_selector, images_array) {
		this.index = 0;
		this.gallery_element = document.querySelector(gallery_selector);
		this.image_element = this.gallery_element.querySelector('.oopgallery-image');
		this.image_filenames = images_array;
		let gallery_object = this;
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-next').addEventListener('click', function (event) {
			gallery_object.gotoImageNext()

		});
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-previous').addEventListener('click', function (event) {
			gallery_object.gotoImagePrevious()
		});

		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-first').addEventListener('click', function (event) {
			gallery_object.gotoImageFirst()
		});
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-control-last').addEventListener('click', function (event) {
			gallery_object.gotoImageLast()
		});

		this.updateImage();
	}
	updateImage() {
		this.image_element.src = this.image_filenames[this.index]
		this.gallery_element.querySelector('.oopgallery-controls .oopgallery-image-number').innerHTML = `${this.index + 1} / ${this.image_filenames.length}`

	}

	gotoImageNext() {
		this.index++;
		if (this.index >= this.image_filenames.length) {
			this.index = 0
		}
		this.updateImage()

	}
	gotoImagePrevious() {
		this.index--;
		if (this.index === -1) {
			this.index = this.image_filenames.length - 1;
		}
		this.updateImage()
	}

	gotoImageFirst() {
		this.index = 0
		this.updateImage()
	}

	gotoImageLast() {
		this.index = this.image_filenames.length - 1;
		this.updateImage()
	}


	addImage(string) {

	}
	addImages(array) {

	}


}