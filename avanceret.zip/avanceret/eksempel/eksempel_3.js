
let spiller = function (fornavn, efternavn) {
    this.fornavn = fornavn;
    this.efternavn = efternavn;
    this.status = false;
    this.point = 0;
    this.skiftStatus = function () {
        this.status = !this.status;
    };
    this.givPoint = function (antal) {
        this.point += antal;
    };
    this.profil = function () {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`
    };

}
let spiller_1 = new spiller('palle', 'Olsen');
let spiller_2 = new spiller('Tina', 'jensen');

spiller_1.skiftStatus();
spiller_1.givPoint(5);

spiller_2.givPoint(-10);

console.log(`1. ${spiller_1.profil()}\n2. ${spiller_2.profil()}`);