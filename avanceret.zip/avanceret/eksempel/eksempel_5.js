
class spiller {
    constructor(fornavn, efternavn) {
        this.fornavn = fornavn;
        this.efternavn = efternavn;
        this.status = false;
        this.point = 0;

    }
    skiftStatus() {
        this.status = !this.status;
    }
    givPoint(antal) {
        this.point += antal;
    }
    profil() {
        return `${this.fornavn} ${this.efternavn} har ${this.point} point ${this.status ? "(aktiv)" : "(ikke aktiv)"}`;
    }

}

let spillerliste = [];
spillerliste.push(new spiller("peter", "hansen"))
spillerliste.push(new spiller("peter", "jensen"))


spillerliste.forEach(function (spiller) {
    spiller.givPoint(5)
    spillerliste[0].givPoint(5)
    console.log(spiller.profil())
})
